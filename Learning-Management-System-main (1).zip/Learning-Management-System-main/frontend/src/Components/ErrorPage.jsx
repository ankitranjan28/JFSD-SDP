import React from 'react'

function ErrorPage() {
  return (
    <div style={{paddingTop:'50px'}}><h2 style={{color:'red'}}>Error Page...</h2></div>
  )
}

export default ErrorPage;